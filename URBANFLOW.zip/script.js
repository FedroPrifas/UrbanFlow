document.addEventListener("DOMContentLoaded", () => {
    lucide.createIcons();
});

// Menu hambúrguer para dispositivos móveis
function toggleMenu() {
    const nav = document.getElementById('nav-links');
    nav.classList.toggle('active');
}

// Botão interativo para mostrar e ocultar as vantagens
function alternarDetalhes(idElemento) {
    const elemento = document.getElementById(idElemento);
    elemento.classList.toggle('ativo');
    
    const botao = event.target;
    if (elemento.classList.contains('ativo')) {
        botao.textContent = "Ocultar Vantagens";
    } else {
        botao.textContent = "Ver Vantagens do Sistema";
    }
}